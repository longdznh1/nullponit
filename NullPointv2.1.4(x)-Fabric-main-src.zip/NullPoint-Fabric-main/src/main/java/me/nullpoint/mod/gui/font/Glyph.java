package me.nullpoint.mod.gui.font;

record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {
}