package me.nullpoint.mod.modules.impl.render.skybox;

public class BackgroundInfo {
    public static final float fogColorRed = 0.3061791f;
    public static final float fogColorGreen = 0.2449433f;
    public static final float fogColorBlue = 0.3061791f;
    public static final float fogDensity = 1.0f;
    public static final float blindness = 0.0f;
}
