package me.nullpoint.mod.modules.impl.client;

import me.nullpoint.mod.modules.Module;

public class MainMenu extends Module {

    public MainMenu() {
        super("MainMenu", Category.Client);
    }
}
