package me.nullpoint.api.interfaces;

import net.minecraft.text.Text;

public interface IChatHud {
    void nullpoint_nextgen_master$add(Text message, int id);
}
