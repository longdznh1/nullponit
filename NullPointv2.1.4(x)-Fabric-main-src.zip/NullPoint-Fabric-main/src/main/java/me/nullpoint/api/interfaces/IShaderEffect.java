package me.nullpoint.api.interfaces;

import net.minecraft.client.gl.Framebuffer;

public interface IShaderEffect {
    void nullpoint_nextgen_master$addFakeTargetHook(String name, Framebuffer buffer);
}