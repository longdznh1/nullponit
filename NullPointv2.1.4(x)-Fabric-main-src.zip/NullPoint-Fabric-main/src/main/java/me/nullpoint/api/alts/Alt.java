package me.nullpoint.api.alts;

public class Alt {
	private String email;

	public Alt(String email) {
		this.email = email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return this.email;
	}
}
