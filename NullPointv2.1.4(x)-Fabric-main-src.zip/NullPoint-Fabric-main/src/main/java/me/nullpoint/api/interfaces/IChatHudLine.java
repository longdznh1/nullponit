package me.nullpoint.api.interfaces;

public interface IChatHudLine {
    int nullpoint_nextgen_master$getId();
    void nullpoint_nextgen_master$setId(int id);
}
