package me.nullpoint.socket.enums;



/**
 * @author DreamDev
 * @since 4/8/2024
 */
public enum ConnectionState {
    CONNECTED,
    DISCONNECTED,
    CONNECTING
}